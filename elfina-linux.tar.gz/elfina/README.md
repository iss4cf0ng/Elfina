# Elfina
Elfina is an ELF file loader for multiple platforms, including x86 and x64 architecture.

<p align="center">
    <img src="https://iss4cf0ng.github.io/images/meme/himari_elf.png" width="800">
</p>

## Background
This project is allow

## Quick Start
### Requirement
```
sudo apt install gcc-multilib
```

### Usage
```
wget https://github.com/iss4cf0ng/Elfina/releases/latest/download/elfina-linux.tar.gz
tar -xzf elfina-linux.tar.gz
cd ./elfina
make

./elfina --info <elf_path>
./elfina --mmap <elf_path> [arguments]
./elfina --memfd <elf_path> [arguments] 
```

